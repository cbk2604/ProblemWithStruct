//: Playground - noun: a place where people can play

import UIKit

class Account {
    var alias: String
    
    init(alias: String) {
        self.alias = alias
    }
}

struct User {
    var isActive: Bool
    var account: Account
}

var depositAccount = Account(alias: "USD")
var firstUser = User(isActive: true, account: depositAccount)

var secondUser = firstUser
secondUser.account.alias = "GB"
print(secondUser.account.alias)
print(firstUser.account.alias)
