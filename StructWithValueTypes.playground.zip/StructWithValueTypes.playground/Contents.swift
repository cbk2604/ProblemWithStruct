//: Playground - noun: a place where people can play

import UIKit

struct Account {
    var alias: String
}

struct User {
    var isActive: Bool
    var account: Account
}

var depositAccount = Account(alias: "USD")
var firstUser = User(isActive: true, account: depositAccount)

var secondUser = firstUser
secondUser.isActive = false
print(secondUser.isActive)
print(firstUser.isActive)
